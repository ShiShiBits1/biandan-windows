import { common, scriptManager } from '@kit.AbilityKit';
import { BusinessError } from '@kit.BasicServicesKit';
import { checkIsUserVIP, createNewEventsByAgent, queryMultiDatesEvents, showPopupAfterAdd,
  startPomodoroByAgent } from 'agentmanager';
import { requestSuspendDelay } from 'backgroundtask';
import { completeDiscountTask } from 'discounttasks';
import { getStorage } from 'preferencesdatastore';
import { noticeAllDevices } from 'synctools';
import { TimerControllerData, TimerData, timerStart } from 'timermanager';
import { TabsState } from '../../../src/main/ets/entryAbility/views/components/TabContent';
import { refreshAllForm } from '../../../src/main/ets/formAbility/utils/FormDataManager';
import { republishReminders } from '../../../src/main/ets/workSchedulerExtensionAbility/WorkSchedulerExtensionAbility';

const TAG = 'biandan_BiandanSkill'

export default class BiandanSkill {

  public async CreateNewEvent(info: scriptManager.ArkTSScriptInfo, ...argv: string[]): Promise<void> {
    console.info(TAG, ` CreateNewEvent function`);
    const context = info.context;

    try {
      try {
        await completeDiscountTask("agent_1", context)
      } catch {}
      const isVIP = await checkIsUserVIP(context)
      if (!isVIP) {
        await this.report(info, { code: -1, result: {
          'type': 'result',
          'status': 'failed',
          'errCode': 'ERR_VIP_REQUIRED',
          'suggestion': '该功能为VIP功能，免费额度已用完，请先充值VIP'
        }})
        return;
      }

      console.info(TAG, 'async call', JSON.stringify(argv));
      const param = this.parseParams(argv);
      if (param === undefined) {
        await this.reportArgumentFormatError(info, argv);
        return;
      }
      console.warn(TAG, 'param', JSON.stringify(param));

      /**
       * 通过Agent创建事项（未标可选的参数必填）
       * @param name 事项名称，应该是一个主谓宾的陈述句，动宾短语或者名词短语
       * @param folderId （可选）待办单ID，当同时传入folderId和folderName时，以folderId为准
       * @param folderName （可选）待办单名称（可以是：全部待办，未分类，我的收藏，重要待办，或者任意字符串，优先传入前4种），当同时传入folderId和folderName时，以folderId为准
       * @param isCollectible （可选）是否收藏
       * @param isImportant （可选）是否重要
       * @param isUrgency （可选）是否紧急
       * @param haveNoTime 是否设置时间范围（当haveNoTime为false时，validStartTime和validEndTime必填）
       * @param countNumber （可选）需要完成的次数（或者子任务数，当有子任务时，应该等于子任务名称列表的长度）
       * @param subTaskTitleList （可选）子任务名称（不要凭空产生，只能通过事项的已知信息拆分）
       * @param validStartTime （可选）事项的有效时间范围的开始时间
       * @param validEndTime （可选）事项的有效时间范围的结束时间
       * @param isLoop 是否是循环事项
       * @param startDate （可选）循环的开始日期
       * @param endDate （可选）循环的结束日期
       * @param loopType （可选）1自定义、2每个工作日、3每个休息日、4每一天、5艾宾浩斯
       * @param loopUnit （可选）0天、1周、2月、3年、4农历月、5农历年
       * @param loopBaseNumber （可选）自定义循环的基础间隔
       * @param loopDate （可选）自定义循环的具体内容
       * @param duration （可选）每次循环的持续天数
       * @param remarkContent （可选）事项备注
       * @param isRemind 是否提醒
       * @param remindDateTime （可选）提醒时间
       * @param location （可选）地点名称
       */

      const name: string = (param.name as string | undefined)?.trim() ?? '';
      const folderId: number | undefined = param.folderId as number | undefined;
      const folderName: string | undefined = param.folderName as string | undefined;
      const isCollectible: boolean | undefined = param.isCollectible as boolean | undefined;
      const isImportant: boolean | undefined = param.isImportant as boolean | undefined;
      const isUrgency: boolean | undefined = param.isUrgency as boolean | undefined;
      const haveNoTime: boolean | undefined = param.haveNoTime as boolean | undefined;
      const countNumber: number | undefined = param.countNumber as number | undefined;
      const subTaskTitleList: string[] | undefined = param.subTaskTitleList as string[] | undefined;

      const validStartTimeStr: string | undefined = param.validStartTime as string | undefined;
      const validStartTime: Date | undefined = this.parseDate(validStartTimeStr);
      const validEndTimeStr: string | undefined = param.validEndTime as string | undefined;
      const validEndTime: Date | undefined = this.parseDate(validEndTimeStr);
      const isLoop: boolean | undefined = param.isLoop as boolean | undefined;
      const startDateStr: string | undefined = param.startDate as string | undefined;
      const startDate: Date | undefined = this.parseDate(startDateStr);
      const endDateStr: string | undefined = param.endDate as string | undefined;
      const endDate: Date | undefined = this.parseDate(endDateStr);
      const loopType: number | undefined = param.loopType as number | undefined;
      const loopUnit: number | undefined = param.loopUnit as number | undefined;
      const loopBaseNumber: number | undefined = param.loopBaseNumber as number | undefined;
      const loopDate: string | undefined = param.loopDate as string | undefined;
      const duration: number | undefined = param.duration as number | undefined;
      const remarkContent: string | undefined = param.remarkContent as string | undefined;
      const isRemind: boolean | undefined = param.isRemind as boolean | undefined;
      const remindDateTimeStr: string | undefined = param.remindDateTime as string | undefined;
      const remindDateTime: Date | undefined = this.parseDate(remindDateTimeStr);
      const location: string | undefined = param.location as string | undefined;
      console.warn(TAG, 'parseParams is ok');

      let invalidMessage: string = '';
      if (name.length === 0) {
        invalidMessage = 'name must not be empty';
      } else if (haveNoTime === undefined) {
        invalidMessage = 'haveNoTime is required';
      } else if (isLoop === undefined) {
        invalidMessage = 'isLoop is required';
      } else if (isRemind === undefined) {
        invalidMessage = 'isRemind is required';
      } else if (validStartTimeStr !== undefined && validStartTime === undefined) {
        invalidMessage = 'validStartTime is invalid';
      } else if (validEndTimeStr !== undefined && validEndTime === undefined) {
        invalidMessage = 'validEndTime is invalid';
      } else if (!haveNoTime && (!validStartTime || !validEndTime)) {
        invalidMessage = 'validStartTime and validEndTime are required when haveNoTime is false';
      } else if (validStartTime && validEndTime && validEndTime.getTime() < validStartTime.getTime()) {
        invalidMessage = 'validEndTime must not be earlier than validStartTime';
      } else if (startDateStr !== undefined && startDate === undefined) {
        invalidMessage = 'startDate is invalid';
      } else if (endDateStr !== undefined && endDate === undefined) {
        invalidMessage = 'endDate is invalid';
      } else if (startDate && endDate && endDate.getTime() < startDate.getTime()) {
        invalidMessage = 'endDate must not be earlier than startDate';
      } else if (isLoop && (!startDate || loopType === undefined)) {
        invalidMessage = 'startDate and loopType are required when isLoop is true';
      } else if (!isLoop && (loopType !== undefined || loopUnit !== undefined || loopBaseNumber !== undefined ||
        loopDate !== undefined || duration !== undefined)) {
        invalidMessage = 'loop parameters must not be set when isLoop is false';
      } else if (loopType === 1 && (loopUnit === undefined || loopBaseNumber === undefined || loopBaseNumber < 1)) {
        invalidMessage = 'loopUnit and a positive loopBaseNumber are required when loopType is 1';
      } else if (loopType === 1 && loopUnit !== undefined && loopUnit >= 1 && loopUnit <= 5 && !loopDate) {
        invalidMessage = 'loopDate is required for the selected loopUnit';
      } else if (countNumber !== undefined && countNumber < 1) {
        invalidMessage = 'countNumber must be greater than 0';
      } else if (subTaskTitleList !== undefined && countNumber !== undefined &&
        countNumber !== subTaskTitleList.length) {
        invalidMessage = 'countNumber must equal subTaskTitleList length';
      } else if (duration !== undefined && duration < 1) {
        invalidMessage = 'duration must be greater than 0';
      } else if (remindDateTimeStr !== undefined && remindDateTime === undefined) {
        invalidMessage = 'remindDateTime is invalid';
      } else if (isRemind && !remindDateTime) {
        invalidMessage = 'remindDateTime is required when isRemind is true';
      }

      if (invalidMessage.length > 0) {
        await this.reportInvalidParams(info, invalidMessage, '请检查并补充事项名称、时间、循环或提醒信息。');
        return;
      }

      console.log(TAG, "CreateNewEventsByAgent", "name", name, "folderId", folderId, "folderName", folderName,
        "isCollectible", isCollectible, "isImportant", isImportant, "isUrgency", isUrgency, "haveNoTime", haveNoTime,
        "countNumber", countNumber, "subTaskTitleList", subTaskTitleList, "validStartTime", validStartTime,
        "validEndTime", validEndTime, "isLoop", isLoop)

      const result = await createNewEventsByAgent(name, folderId, folderName, isCollectible, isImportant, isUrgency,
        haveNoTime as boolean, countNumber, subTaskTitleList, validStartTime, validEndTime, isLoop as boolean, startDate,
        endDate, loopType, loopUnit, loopBaseNumber, loopDate, duration, remarkContent, isRemind as boolean,
        remindDateTime, location, context)
      console.log(TAG, "CreateNewEvent", "result", result)

      if (result) {
        try {
          showPopupAfterAdd(validStartTime ?? startDate ?? new Date())
          requestSuspendDelay("刷新卡片并提交通知")
          noticeAllDevices(context)
          republishReminders(context, AppStorage.get<boolean>("isDoneEventRemind") ?? true)
          refreshAllForm(context)
        } catch (e) {
          const err = e as BusinessError;
          console.error(TAG, `post-create refresh failed, code: ${err.code}, message: ${err.message}`);
        }

        await this.report(info, { code: 0, result: {
          'type': 'result',
          'status': 'success',
          'suggestion': `${name}已添加到便单，请打开便单APP查看`
        }})
        return;
      }

      await this.report(info, { code: -1, result: {
        'type': 'result',
        'status': 'failed',
        'errCode': 'ERR_INTERNAL',
        'errMsg': 'createNewEventsByAgent returned false',
        'suggestion': `${name}添加失败，请稍后再试`
      }})
    } catch (e) {
      await this.reportInternalError(info, e as Object, '添加事项失败，请稍后再试。');
    }
  }

  public async QueryMultiDatesEvents(info: scriptManager.ArkTSScriptInfo, ...argv: string[]): Promise<void> {
    const context = info.context;

    try {
      try {
        await completeDiscountTask("agent_2", context)
      } catch {}
      const isVIP = await checkIsUserVIP(context)
      if (!isVIP) {
        await this.report(info, { code: -1, result: {
          'type': 'result',
          'status': 'failed',
          'errCode': 'ERR_VIP_REQUIRED',
          'suggestion': '该功能为VIP功能，免费额度已用完，请先充值VIP'
        }})
        return;
      }

      /**
       * 查询某个待办单在某个时间段内的所有事项
       * @param folderId （可选）待办单ID，当同时传入folderId和folderName时，以folderId为准
       * @param folderName （可选）待办单名称，没有说明分类时使用全部待办
       * @param startDate 时间段的开始时间，精确到分
       * @param endDate 时间段的结束时间，精确到分
       */
      console.info(TAG, 'async call', JSON.stringify(argv));
      const param = this.parseParams(argv);
      if (param === undefined) {
        await this.reportArgumentFormatError(info, argv);
        return;
      }

      console.warn(TAG, 'param', JSON.stringify(param));

      const folderId: number | undefined = param.folderId as number | undefined;
      const folderName: string | undefined = param.folderName as string | undefined;
      const startDateStr: string | undefined = param.startDate as string | undefined;
      const startDate: Date | undefined = this.parseDate(startDateStr);
      const endDateStr: string | undefined = param.endDate as string | undefined;
      const endDate: Date | undefined = this.parseDate(endDateStr);

      if (!startDate || !endDate || endDate.getTime() < startDate.getTime()) {
        await this.reportInvalidParams(info, 'startDate or endDate is invalid',
          '查询出错了，请检查输入的日期格式和时间范围是否正确。');
        return;
      }

      const result = await queryMultiDatesEvents(folderId, folderName, startDate, endDate, context)
      console.log(TAG, "QueryMultiDatesEvents", "result", JSON.stringify(result))

      const data: Record<string, Object> = {
        'events': result as Object
      };
      await this.report(info, { code: 0, result: {
        'type': 'result',
        'status': 'success',
        'data': data
      }})
    } catch (e) {
      await this.reportInternalError(info, e as Object, '查询失败，请稍后再试。');
    }
  }

  public async StartPomodoro(info: scriptManager.ArkTSScriptInfo, ...argv: string[]): Promise<void> {
    const context = info.context;
    console.log(TAG,"StartPomodoro")

    try {
      try {
        await completeDiscountTask("agent_3", context)
      } catch {}
      AppStorage.setOrCreate<number>('selectPos', TabsState.TOMATO)
      const isVIP = await checkIsUserVIP(context)
      if (!isVIP) {
        await this.report(info, { code: -1, result: {
          'type': 'result',
          'status': 'failed',
          'errCode': 'ERR_VIP_REQUIRED',
          'suggestion': '该功能为VIP功能，免费额度已用完，请先充值VIP'
        }})
        return;
      }

      /**
       * 启动专注
       * 当为倒计时类型时，请设定TimerType为0，tomatoCount为1，eachFocusTime为倒计时的时间
       * @param TimerType （可选）倒计时/番茄钟为0，正计时为1
       * @param eachFocusTime （可选）每轮专注时间，单位分钟，必须是5的倍数，范围5~180
       * @param eachRestTime （可选）每轮休息时间，单位分钟，范围1~150，TimerType为1时不填
       * @param RemindingPauseTime （可选）整次番茄钟可休息时间，单位分钟，范围1~150，TimerType为1时不填
       * @param tomatoCount （可选）整次番茄钟轮数，范围1~99，TimerType为1时不填
       * @param eventName （可选）专注事项名称
       */
      console.info(TAG, 'async call', JSON.stringify(argv));
      const param = this.parseParams(argv);
      if (param === undefined) {
        await this.reportArgumentFormatError(info, argv);
        return;
      }
      console.warn(TAG, 'param', JSON.stringify(param));

      const TimerType: number | undefined = param.TimerType as number | undefined;
      const eachFocusTime: number | undefined = param.eachFocusTime as number | undefined;
      const eachRestTime: number | undefined = param.eachRestTime as number | undefined;
      const RemindingPauseTime: number | undefined = param.RemindingPauseTime as number | undefined;
      const tomatoCount: number | undefined = param.tomatoCount as number | undefined;
      const eventName: string | undefined = param.eventName as string | undefined;

      let invalidMessage: string = '';
      if (TimerType !== undefined && TimerType !== 0 && TimerType !== 1) {
        invalidMessage = 'TimerType must be 0 or 1';
      } else if (eachFocusTime !== undefined &&
        (eachFocusTime < 5 || eachFocusTime > 180 || eachFocusTime % 5 !== 0)) {
        invalidMessage = 'eachFocusTime must be a multiple of 5 between 5 and 180';
      } else if (eachRestTime !== undefined && (eachRestTime < 1 || eachRestTime > 150)) {
        invalidMessage = 'eachRestTime must be between 1 and 150';
      } else if (RemindingPauseTime !== undefined &&
        (RemindingPauseTime < 1 || RemindingPauseTime > 150)) {
        invalidMessage = 'RemindingPauseTime must be between 1 and 150';
      } else if (tomatoCount !== undefined && (tomatoCount < 1 || tomatoCount > 99)) {
        invalidMessage = 'tomatoCount must be between 1 and 99';
      } else if (TimerType === 1 &&
        (eachRestTime !== undefined || RemindingPauseTime !== undefined || tomatoCount !== undefined)) {
        invalidMessage = 'rest time and tomatoCount must not be set when TimerType is 1';
      }

      if (invalidMessage.length > 0) {
        await this.reportInvalidParams(info, invalidMessage, '请检查专注时长、休息时长和轮数。');
        return;
      }


      AppStorage.setOrCreate<number>('TimerType', (getStorage("settings", "TimerType", context) ?? 0) as number)
      AppStorage.setOrCreate<number>('eachFocusTime', (getStorage("settings", "eachFocusTime", context) ?? 25) as number)
      AppStorage.setOrCreate<number>('eachRestTime', (getStorage("settings", "eachRestTime", context) ?? 10) as number)
      AppStorage.setOrCreate<number>('RemindingPauseTime', (getStorage("settings", "RemindingPauseTime", context) ?? 3) as number)
      AppStorage.setOrCreate<number>('tomatoCount', (getStorage("settings", "tomatoCount", context) ?? 5) as number)

      await startPomodoroByAgent(TimerType, eachFocusTime, eachRestTime, RemindingPauseTime, tomatoCount, eventName)

      let thisTimerType: number = (AppStorage.get<number>("TimerType") ?? TimerType) ?? 0
      let thisTomatoCount: number = (AppStorage.get<number>("tomatoCount") ?? tomatoCount) ?? 5
      let thisEachFocusTime: number = (AppStorage.get<number>("eachFocusTime") ?? eachFocusTime) ?? 25
      let thisEachRestTime: number = (AppStorage.get<number>("eachRestTime") ?? eachRestTime) ?? 10
      let thisRemindingPauseTime: number = (AppStorage.get<number>("RemindingPauseTime") ?? RemindingPauseTime) ?? 3
      let timerController = new TimerControllerData(
        thisEachFocusTime,
        thisEachRestTime,
        thisRemindingPauseTime,
        thisTomatoCount
      ) as TimerControllerData
      let timerData = new TimerData(
        thisEachFocusTime,
        thisEachRestTime,
        thisRemindingPauseTime,
        thisTomatoCount
      ) as TimerData
      timerData.timerType = thisTimerType

      timerData.eventTitle = AppStorage.get<string | undefined>('timerData_eventTitle') ?? eventName

      AppStorage.setOrCreate<TimerControllerData>('timerController', timerController)
      AppStorage.setOrCreate<TimerData>('timerData', timerData)

      timerStart(timerController, timerData, context)

      AppStorage.setOrCreate<string | undefined>('timerData_eventTitle', undefined)
      AppStorage.setOrCreate<boolean>('isTimerRunningStart', true)

      await this.report(info, { code: 0, result: {
        'type': 'result',
        'status': 'success',
        'suggestion': `番茄钟已启动`
      }})
    } catch (e) {
      await this.reportInternalError(info, e as Object, '启动专注失败，请稍后再试。');
    }
  }

  /**
   * 解析宿主传入的参数。
   *
   * ArkTSScript 在不同版本/调用路径下有两种传参形式：
   * 1. 一个 JSON 对象（可能是 JSON 字符串，也可能已经是原生对象）；
   * 2. 将对象展开成 argv。展开后参数只保留实际提供的字段，并按字段名的
   *    字典序传递；boolean/number 也可能以原生类型传入，而不是字符串。
   *
   * 因此不能再假设 argv 一定按本文件中的声明顺序排列，也不能对所有 argv
   * 无条件调用 trim()。
   */
  private parseParams(argv: string[]): Record<string, Object> | undefined {
    if (argv.length !== 1) {
      console.warn(TAG, `invalid argv count: ${argv.length}`);
      return undefined;
    }

    const rawValue: Object = argv[0] as Object;

    if (typeof rawValue !== 'string') {
      console.warn(TAG, 'argv[0] must be a JSON string');
      return undefined;
    }

    const text: string = (rawValue as string).trim();
    if (text.length === 0) {
      console.warn(TAG, 'argv[0] must not be empty');
      return undefined;
    }

    let result: Record<string, Object> | undefined =
      this.tryParseJsonObject(text);

    /*
     * 保留对命令行额外转义形式的兼容。
     * 先尝试原始 JSON，失败后再尝试去除 \"。
     */
    if (result === undefined &&
      text.startsWith('{') && text.endsWith('}')) {
      result = this.tryParseJsonObject(text.replace(/\\"/g, '"'));
    }

    if (result === undefined) {
      console.warn(TAG, 'argv[0] is not a valid JSON object');
    }

    return result;
  }

  private tryParseJsonObject(
    text: string
  ): Record<string, Object> | undefined {
    try {
      const parsed: Object = JSON.parse(text) as Object;

      if (parsed === null ||
        typeof parsed !== 'object' ||
        Array.isArray(parsed)) {
        return undefined;
      }

      return parsed as Record<string, Object>;
    } catch (e) {
      console.warn(TAG, `parse JSON object failed: ${(e as Error).message}`);
      return undefined;
    }
  }

  private async reportArgumentFormatError(
    info: scriptManager.ArkTSScriptInfo,
    argv: string[]
  ): Promise<void> {
    let errMsg: string;

    if (argv.length !== 1) {
      errMsg =
        `参数传递格式错误：argv.length 必须为 1，实际为 ${argv.length}。`;
    } else {
      errMsg =
        '参数传递格式错误：argv[0] 必须是可解析的 JSON 对象字符串。';
    }

    await this.reportInvalidParams(
      info,
      errMsg,
      '请先对完整参数对象执行 JSON.stringify，再将结果作为唯一 argv[0] 传入；不要使用 Object.values 或展开为多个位置参数。命令行调用时，请按要求转义内部双引号。'
    );
  }

  private parseDate(value: string | undefined): Date | undefined {
    if (!value) {
      return undefined;
    }

    // The app uses local wall-clock times. The host may append an ISO-8601
    // offset (for example +08:00); remove it before constructing Date so that
    // 2026-09-09T00:00:00+08:00 remains local midnight instead of becoming
    // the previous day after conversion to UTC.
    const localValue: string = value.trim().replace(/(?:Z|[+-]\d{2}:?\d{2})$/, '');
    const date = new Date(localValue);
    return isNaN(date.getTime()) ? undefined : date;
  }

  private async reportInvalidParams(info: scriptManager.ArkTSScriptInfo, errMsg: string,
    suggestion: string): Promise<void> {
    await this.report(info, { code: -1, result: {
      'type': 'result',
      'status': 'failed',
      'errCode': 'ERR_INVALID_PARAMS',
      'errMsg': errMsg,
      'suggestion': suggestion
    }})
  }

  private async reportInternalError(info: scriptManager.ArkTSScriptInfo, error: Object,
    suggestion: string): Promise<void> {
    const err = error as BusinessError;
    const message: string = err.message ?? 'unknown internal error';
    console.error(TAG, `Skill execution failed, code: ${err.code}, message: ${message}`);
    await this.report(info, { code: -1, result: {
      'type': 'result',
      'status': 'failed',
      'errCode': 'ERR_INTERNAL',
      'errMsg': message,
      'suggestion': suggestion
    }})
  }

  private async report(info: scriptManager.ArkTSScriptInfo, result: scriptManager.ExecuteResult): Promise<void> {
    try {
      await scriptManager.completeArkTSScriptInApp(info.context, info.requestCode, result);
    } catch (e) {
      const err = e as BusinessError;
      console.error(`completeArkTSScriptInApp failed, code: ${err.code}, message: ${err.message}`);
    }
  }
}
