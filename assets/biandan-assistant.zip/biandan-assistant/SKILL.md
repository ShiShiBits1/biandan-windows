---
name: biandan-assistant
description: >-
  在便单 APP 中新建/创建待办事项、查询某个时间段内的事项、启动番茄钟/倒计时/正计时专注。
  可响应用户意图如「创建买牛奶的待办」「明天9点提醒我提交报告」「每个工作日8点锻炼」
  「创建循环计划」「查询本周的重要待办」「我明天有什么安排」「开始25分钟番茄钟」「专注写报告50分钟」。
  不适用于删除、编辑或标记完成已有事项，设置系统闹钟，查询系统日历。
---

# 便单助手

支持创建事项（方式 A 变体：`CreateNewEvent`/`CreateRemindEvent`/`CreateNoTimeEvent`，方式 B 函数：`CreateNewEvent`）、查询事项 `QueryMultiDatesEvents`、启动专注 `StartPomodoro`。不支持删除、修改事项，不处理系统日历或系统闹钟。缺少必要业务信息时询问用户，不臆造。

## 调用前必须完成的两步

### 第一步：按当前环境选 A 或 B

| 当前可用能力 | 使用方式 |
| --- | --- |
| 鸿蒙端侧提供 `exec-cli` 和 `ohos-arkTSScript` | 用 B；两种方式都可用时也用 B |
| 云端小艺 Work 等环境只提供已注册的便单 `invoke` 工具 | 用 A；不要在云端沙箱执行 B 命令 |
| 两者都不可用 | 告知当前环境无法调用便单，停止 |

**A：invoke。** 按实际工具定义选择函数，应用标识为 `cn.biandangroup.biandan`。创建事项按场景选变体：带时间无提醒用 `CreateNewEvent`、带提醒用 `CreateRemindEvent`、无时间用 `CreateNoTimeEvent`；布尔字段（haveNoTime/isRemind/isLoop/isImportant/isUrgency）已由变体内置，调用方不要传，只传工具 schema 中定义的动态字段。查询与专注直接用 `QueryMultiDatesEvents`/`StartPomodoro`。不要猜测参数名，也不要擅自改变工具 schema。

**B：exec-cli / ohos-arkTSScript。** 使用下方完整示例结构：`--skillName 'biandan-assistant' --scriptPath 'scripts/BiandanSkill.ets' --functionName '<函数名>' --args '<内部双引号已转义的完整JSON字符串>'`。`--args` 后只有一个完整参数。

### 第二步：先把全部业务参数压成一个字符串，再调用

**首次调用就必须完成，不能等报错后才压参数。所有函数、A 和 B 都遵守同一个要求：ETS 只接收一个 JSON 对象字符串。**

先构造业务对象 `params`，再执行一次 `JSON.stringify(params)` 得到 `payload`。保留字段名，布尔和数值保留原类型；路由字段不放入业务对象。已经是 JSON 对象字符串时不再 stringify。

以查询事项为例，去除命令传输层转义后，参数必须等价于：

```javascript
// 这是 ETS 入口参数示意，不是 invoke 的工具字段定义。
argv = ['{"folderName":"全部待办","startDate":"2026-10-25 00:00","endDate":"2026-10-25 23:59"}'];
```

**发送前检查：`argv.length === 1`；`typeof argv[0] === 'string'`；`payload` 可解析成对象，且经过调用层转义后仍作为一个参数传入。** 禁止将 folderName、startDate、endDate 拆成三个参数，禁止 `Object.values`，禁止直接传原生对象或将整个参数数组序列化。

**方式 B 必须转义内部双引号，即把 `"` 写成 `\"`，再将完整内容作为 `--args` 的唯一参数。即使示例外层有单引号，也不要省略这里要求的双引号转义。**

```text
序列化后的 payload：{"folderName":"全部待办"}
B 命令中的参数：--args '{\"folderName\":\"全部待办\"}'
```

先序列化业务对象，再对命令传输层转义，这两个步骤都必须做。若 `command` 还要作为外层工具 JSON 的字符串值提交，应对整个命令再做 JSON 字符串编码，使外层 JSON 解码后仍保留下方命令中的 `\"`。A 的字符串入参也必须按其工具 JSON 格式编码；不能把 B 的命令行转义原样套入 A。

ETS 会先尝试直接解析，失败后再将收到的 `\"` 还原为 `"` 并解析对象。字符串值本身包含引号、反斜杠或换行时，先由 `JSON.stringify` 编码，再处理调用层转义；不得直接拼接用户文本。

## 返回结果与错误处理

只有返回 `status: "success"` 才表示业务成功。返回 `ERR_INVALID_PARAMS` 且明确提示“参数传递格式错误”、`argv.length` 或 `argv[0]` 格式不符时，立即重新封装原业务参数，用可用的 B 自动重试一次；不要等用户提醒“压成一个字符串”。B 不可用或重试仍失败则停止并说明实际错误。

业务字段非法按下方约束修正；VIP 不足、APP 不可用、内部错误不通过压参数重试。超时或结果不明时，不自动重放创建/启动操作。不要将参数传递格式错误解释成用户日程数据有问题或暂时网络故障。

## 运行条件与业务约定

- 依赖设备上已安装且可正常运行的便单 APP，版本需支持 ArkTS Skill 调用。未安装或不可用时说明原因；官方安装地址：`https://appgallery.huawei.com/app/detail?id=cn.biandangroup.biandan`。
- 时间统一使用本地 `YYYY-MM-DD HH:mm`。根据用户请求和当前日期计算时间，下方日期只是格式示例，不能直接照搬。
- 启动专注使用宿主的 foreground 前台模式，后台调用可能返回 `-304 intent invalid`。
- A 的必填字段以实际工具定义为准；不能为满足模板填写与业务规则冲突的字段。

## 场景 1：创建事项（CreateNewEvent）

**触发**：用户说"创建一个买牛奶的待办""明天9点提醒我提交报告"等。

**方式 A 路由**：带时间无提醒 → `CreateNewEvent`（name/folderName/validStartTime/validEndTime）；带提醒 → `CreateRemindEvent`（另加 remindDateTime）；无时间 → `CreateNoTimeEvent`（仅 name/folderName）。布尔字段已由变体内置，不要传。下方完整参数结构仅适用于方式 B。

**方式 B 完整调用示例（整个 JSON 是一个参数，不得拆开）**：
```
exec-cli(command: ohos-arkTSScript --skillName 'biandan-assistant' --scriptPath 'scripts/BiandanSkill.ets' --functionName 'CreateNewEvent' --args '{\"name\":\"提交项目周报\",\"folderName\":\"重要待办\",\"haveNoTime\":false,\"validStartTime\":\"2026-08-18 09:00\",\"validEndTime\":\"2026-08-18 09:00\",\"isLoop\":false,\"isRemind\":true,\"remindDateTime\":\"2026-08-18 08:50\"}')
```

**业务参数**：将整个对象 `JSON.stringify` 为一个 JSON 字符串，作为 `--args` 的单一（第一个）参数传入；不要把字段拆成位置数组。参数结构如下：

```json
{
  "type": "object",
  "required": ["name", "haveNoTime", "isLoop", "isRemind"],
  "properties": {
    "name": { "type": "string", "minLength": 1, "description": "事项名称；使用用户已知的动宾短语、名词短语或主谓宾陈述句。" },
    "folderId": { "type": "number", "description": "待办单 ID；与 folderName 同时提供时以 folderId 为准。" },
    "folderName": { "type": "string", "description": "待办单名称。可为全部待办、未分类、我的收藏、重要待办或用户明确说出的名称；无明确分类填未分类。与 folderId 同时提供时以 folderId 为准。" },
    "isCollectible": { "type": "boolean", "description": "是否收藏；未明确则不要填写。" },
    "isImportant": { "type": "boolean", "description": "是否重要；未明确填 false。" },
    "isUrgency": { "type": "boolean", "description": "是否紧急；未明确填 false。" },
    "haveNoTime": { "type": "boolean", "description": "是否设置时间范围；无时间范围时为 true，有时间点或时间范围时为 false（此时 validStartTime 和 validEndTime 必填）。" },
    "countNumber": { "type": "number", "minimum": 1, "description": "需要完成的次数（或子任务数）；有子任务时应等于 subTaskTitleList 的长度。" },
    "subTaskTitleList": { "type": "array", "items": { "type": "string", "minLength": 1 }, "description": "子任务名称（使用主谓宾陈述句、动宾短语或名词短语）；尽量按用户已知信息拆分为子任务，但不得凭空产生。" },
    "validStartTime": { "type": "string", "format": "date-time", "description": "有效时间范围开始，精确到分；必须与 validEndTime 同时填写；循环事项忽略年月日；全天事项为当天 00:00。" },
    "validEndTime": { "type": "string", "format": "date-time", "description": "有效时间范围结束，精确到分；必须与 validStartTime 同时填写；时间点事项与 validStartTime 相等；循环事项忽略年月日；全天事项为当天 23:59。" },
    "isLoop": { "type": "boolean", "description": "是否是循环事项。" },
    "startDate": { "type": "string", "format": "date-time", "description": "循环开始日期，精确到天；isLoop 为 true 时必填。" },
    "endDate": { "type": "string", "format": "date-time", "description": "循环结束日期，精确到天。" },
    "loopType": { "type": "number", "enum": [0, 1, 2, 3, 4, 5], "description": "循环类型，仅当 isLoop 为 true 时才能填且必填：0 不循环（仅一次）；1 自定义；2 每个工作日；3 每个休息日；4 每一天；5 艾宾浩斯。" },
    "loopUnit": { "type": "number", "enum": [0, 1, 2, 3, 4, 5], "description": "循环参考周期，仅当 loopType=1（自定义）时才能填且必填：0 天、1 周、2 月、3 年、4 农历月、5 农历年。" },
    "loopBaseNumber": { "type": "number", "minimum": 1, "description": "自定义循环的基础间隔，仅当 loopType=1 时才能填且必填；填 n 表示每 n 个 loopUnit 单位（如每 n 天/周/月）循环一次。" },
    "loopDate": { "type": "string", "description": "自定义循环的具体内容，仅当 loopUnit 为 1、2、3、4、5 时才能填且必填。loopUnit=1（周）时：0~6 表示周日到周六，用“,”拼接（如周一到周五为 \"1,2,3,4,5\"）；loopUnit=2（月）时：1~31 表示该月第几天、32 表示该月最后一天，用“,”拼接（如 7~9 号为 \"7,8,9\"）；loopUnit=3（年）时：用“-”拼接月份和日期、用“,”拼接多组（如 6月6日和2月8日为 \"06-06,02-08\"）；loopUnit=4（农历月）时：1~30 表示该农历月第几天，用“,”拼接（如十五和廿六为 \"15,26\"）；loopUnit=5（农历年）时：用“-”拼接月份和日期的阿拉伯数字、用“,”拼接多组（如四月廿六为 \"04-26\"）。" },
    "duration": { "type": "number", "minimum": 1, "description": "每次循环的持续天数；若需调整整个循环的起始时间，请调整循环开始/结束日期。" },
    "remarkContent": { "type": "string", "description": "备注信息；将事项名称和子任务放不下的信息都放在这里。" },
    "isRemind": { "type": "boolean", "description": "是否提醒；用户没有明确要求提醒时为 false。" },
    "remindDateTime": { "type": "string", "format": "date-time", "description": "提醒具体时间，精确到分；isRemind 为 true 时必填；循环事项忽略年月日。" },
    "location": { "type": "string", "description": "事项的地点位置名称；按用户明确说出的地点填写。" }
  },
  "allOf": [
    {
      "if": { "properties": { "haveNoTime": { "const": false } }, "required": ["haveNoTime"] },
      "then": { "required": ["validStartTime", "validEndTime"] }
    },
    {
      "if": { "properties": { "isRemind": { "const": true } }, "required": ["isRemind"] },
      "then": { "required": ["remindDateTime"] }
    },
    {
      "if": { "properties": { "isLoop": { "const": true } }, "required": ["isLoop"] },
      "then": { "required": ["startDate", "loopType"] }
    },
    {
      "if": { "properties": { "loopType": { "const": 1 } }, "required": ["loopType"] },
      "then": { "required": ["loopUnit", "loopBaseNumber"] }
    }
  ]
}
```

**业务约定**：
- `name` 必填；`folderName` 待办单名，无明确分类填"未分类"。
- 无时间事项：`haveNoTime=true`，省略 `validStartTime/validEndTime`，不凭空补日期。
- 时间格式统一 `YYYY-MM-DD HH:mm`（本地时间），全天事项 validStartTime=当天 00:00、validEndTime=当天 23:59，时间点事项两者相同。
- 循环事项：`isLoop=true`（默认非循环时填 false）；`loopType` 必填，1 为自定义时必须同时提供 `loopUnit` 与 `loopBaseNumber`；`loopUnit` 为 1~5 时提供 `loopDate`。不循环/仅一次时 `loopType=0`。

---

## 场景 2：查询多个日期的事项（QueryMultiDatesEvents）

**触发**：用户说"查询本周的重要待办""我明天有什么安排"等。

**方式 B 完整调用示例（整个 JSON 是一个参数，不得拆开）**：
```
exec-cli(command: ohos-arkTSScript --skillName 'biandan-assistant' --scriptPath 'scripts/BiandanSkill.ets' --functionName 'QueryMultiDatesEvents' --args '{\"folderName\":\"全部待办\",\"startDate\":\"2026-08-18 00:00\",\"endDate\":\"2026-08-24 23:59\"}')
```

**参数**：`startDate`/`endDate` 必填，格式 `YYYY-MM-DD HH:mm`，endDate 不得早于 startDate；`folderId`/`folderName` 待办单定位，folderName 无分类信息填"全部待办"。
- 返回 success 时，从 `data.events` 读取事项。

---

## 场景 3：启动专注（StartPomodoro）

**触发**：用户说"开始25分钟番茄钟""专注写报告50分钟"等。使用 foreground 前台模式启动专注。

**方式 B 完整调用示例（整个 JSON 是一个参数，不得拆开）**：
```
exec-cli(command: ohos-arkTSScript --skillName 'biandan-assistant' --scriptPath 'scripts/BiandanSkill.ets' --functionName 'StartPomodoro' --args '{\"TimerType\":0,\"eachFocusTime\":25,\"eachRestTime\":5,\"tomatoCount\":1,\"eventName\":\"学英语\"}')
```

**参数**：`TimerType` 0=倒计时/番茄钟，1=正计时；`eachFocusTime` 5-180 且为 5 的倍数；`eachRestTime` 1-150（TimerType=1 不填）；`RemindingPauseTime` 整次可休息分钟（TimerType=1 不填）；`tomatoCount` 1-99（倒计时为 1，TimerType=1 不填）；`eventName` 用户明确说出的专注事项。

**成功后的动作**：`StartPomodoro` 返回 `status: "success"` 后，尝试使用当前环境提供的应用打开能力拉起便单 APP（`cn.biandangroup.biandan`）；若便单已在前台，则无需重复拉起。没有应用打开能力或拉起失败时，告知专注已启动，可手动打开便单查看；不要因此再次调用 `StartPomodoro`，也不要将已成功的专注报告为失败。